from . import _version
import os

__version__ = _version.__version__

